#ifndef TYPES_H
#define TYPES_H
/*include*/
#include<stdio.h>
#include<string.h>
#include<errno.h>
/*defines*/
#define INIT 0
#define FALSE 0
#define TRUE !FALSE
/*typedef*/
typedef unsigned char boolean;
typedef unsigned char uint8;
typedef char int8;
typedef unsigned short uint16;
typedef short int16;
typedef unsigned int uint32;
typedef int int32;

#endif


